AQUAIVOLT exact model verification package - 20 November 2026
Models are unchanged. Both ONNX artifacts and original fitted pipelines are included.
Use Python 3.12. Install requirements-check.txt for inference.
Save a live /api/ml/predict response for request.json as response.json.
python independent-model-check.py --models models --request request.json --expected response.json --output comparison.json
For reference training/evaluation reconstruction, install requirements-reference-evaluation.txt:
python reproduce-reference-evaluation.py --models models --workbooks source-workbooks --output recreated-evaluation.json
Read documentation/MODEL_VERIFICATION_2026-11-20.md for features, units, targets, preprocessing, split rules, evaluation and limits.
Live serving source/deployment identity: authenticated GET /api/ml/artifacts.
That source revision identifies serving code, not the unrecovered original training transaction.
CHECKSUMS.json covers all files except itself. Compare ONNX hashes with live API results.
The reconstructed procedure reproduces the saved fits and archived metrics; it is not independent plant validation.
